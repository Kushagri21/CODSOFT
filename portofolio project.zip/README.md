# Portfolio_Project

In this project, I build a portfolio website using HTML & CSS. It contain various section which display the information about me, my skills, my projects, my resume, etc.
